var classmodel_1_1_game_model =
[
    [ "GameModel", "classmodel_1_1_game_model.html#a9b1b28ce881943f0f4035cf5fbd3860d", null ],
    [ "getBall", "classmodel_1_1_game_model.html#a8523896367260852dad583e37651f87c", null ],
    [ "getBomb", "classmodel_1_1_game_model.html#aa53f717eeb13366ffe506363efd1637f", null ],
    [ "getComputer", "classmodel_1_1_game_model.html#a0bcf575adf7119282fe0a45e3f6bb5df", null ],
    [ "getComputerPaddle", "classmodel_1_1_game_model.html#a15542a275095daae439adcb8b5782055", null ],
    [ "getPlayer", "classmodel_1_1_game_model.html#a67c62132a9e3578c642613d54350ca75", null ],
    [ "getPlayerPaddle", "classmodel_1_1_game_model.html#a8bdb8971824c753c8074ccc0fadf56fc", null ],
    [ "setBall", "classmodel_1_1_game_model.html#a76b4c67d259ce96f0bd20f6c27284ac0", null ],
    [ "setBomb", "classmodel_1_1_game_model.html#af426dea55d8fff1227dea8bb74530611", null ],
    [ "b", "classmodel_1_1_game_model.html#a1b56c649031a3fb9c0b2930edf719de3", null ],
    [ "p_player", "classmodel_1_1_game_model.html#a46b846cead279b52545bb014f946fe47", null ],
    [ "player", "classmodel_1_1_game_model.html#aa7997c685bdb47e1af57ea496f4128c0", null ]
];