var searchData=
[
  ['height',['HEIGHT',['../classmodel_1_1_paddle.html#a2e269d6e61b7b809c3b90c2007994fcf',1,'model::Paddle']]],
  ['highscores',['highScores',['../classview_1_1_welcome.html#a824f339b982b2e96f4c6b86287154c5a',1,'view.Welcome.highScores()'],['../classview_1_1_welcome.html#a5d23e93f1a81a2520d5635ed7d8d5920',1,'view.Welcome.highScores()']]]
];
