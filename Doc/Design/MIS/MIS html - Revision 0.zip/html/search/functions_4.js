var searchData=
[
  ['exit',['exit',['../classview_1_1_welcome.html#a78b2940bddd27a89b9462192cbdeaa65',1,'view::Welcome']]]
];
