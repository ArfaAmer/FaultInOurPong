var searchData=
[
  ['w',['w',['../classstart_game_1_1_game_controller.html#a5478c83b51a049015f9d4d6bc5c61607',1,'startGame::GameController']]],
  ['welcome',['welcome',['../classview_1_1_game_view.html#a473510516d38bd1b016321b06962f0b0',1,'view::GameView']]],
  ['width',['WIDTH',['../classmodel_1_1_paddle.html#a960e83432472e421bd4c5fb3c594e93f',1,'model::Paddle']]]
];
