var searchData=
[
  ['highscores',['highScores',['../classview_1_1_welcome.html#a5d23e93f1a81a2520d5635ed7d8d5920',1,'view::Welcome']]]
];
