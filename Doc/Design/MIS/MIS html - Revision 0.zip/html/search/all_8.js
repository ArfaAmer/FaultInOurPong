var searchData=
[
  ['inset',['INSET',['../classmodel_1_1_paddle.html#a4bb13cdef375eba471c680ddc87407ba',1,'model.Paddle.INSET()'],['../classstart_game_1_1_game_controller.html#a5195c030f589da53f78a185e31a5dc9a',1,'startGame.GameController.inset()'],['../classview_1_1_pong_game_display.html#ac202bb5082c22fb3f40ddff2ccc797b5',1,'view.PongGameDisplay.inset()']]]
];
