var searchData=
[
  ['decrementlife',['decrementLife',['../classmodel_1_1_player.html#a5551dad23bcab60638b37c8f54dd6796',1,'model::Player']]],
  ['display',['display',['../classstart_game_1_1_game_controller.html#abe07c8d60c3adbb0993e637b8c725884',1,'startGame.GameController.display()'],['../classview_1_1_game_view.html#a47f32011f21917818ac92ebecba5dc5b',1,'view.GameView.display()']]]
];
