var searchData=
[
  ['nolife',['NOLIFE',['../classmodel_1_1_player.html#ad422bd3896f6c86c74fe49be0cae6759',1,'model::Player']]]
];
