var searchData=
[
  ['nofileavailmessage',['noFileAvailMessage',['../classview_1_1_game_view.html#a7320789eb48e8b661a1f3a522ef592fb',1,'view::GameView']]]
];
