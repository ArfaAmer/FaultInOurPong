var searchData=
[
  ['record',['record',['../classstart_game_1_1_game_controller.html#a43406d2f3c186834a759743c4c775d14',1,'startGame::GameController']]]
];
