var searchData=
[
  ['load',['load',['../classview_1_1_welcome.html#a4a6c30be81cc7a3b081d3e97a4c84356',1,'view::Welcome']]]
];
