var searchData=
[
  ['tutorial',['tutorial',['../classview_1_1_welcome.html#aaf45e35ac75c1b6f8badd358dd2c2a08',1,'view.Welcome.tutorial()'],['../classview_1_1_tutorial.html#a0b4dd05d8cf555062780668eb39b9c10',1,'view.Tutorial.Tutorial()']]],
  ['tutorialpage',['tutorialPage',['../classview_1_1_game_view.html#a67fd4999f1be51ce360b8bba68e87d9c',1,'view::GameView']]]
];
