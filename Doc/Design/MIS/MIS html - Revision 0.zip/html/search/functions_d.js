var searchData=
[
  ['welcome',['Welcome',['../classview_1_1_welcome.html#ac0d0158b691ccb4dbca2c78145e4a522',1,'view::Welcome']]]
];
