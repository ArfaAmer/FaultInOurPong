var searchData=
[
  ['life',['LIFE',['../classmodel_1_1_player.html#a59153913ee338710aa1a33b68e5d0dbd',1,'model::Player']]],
  ['load',['load',['../classview_1_1_welcome.html#a91a24fdd828b87e1307d4af30693401e',1,'view.Welcome.load()'],['../classview_1_1_welcome.html#a4a6c30be81cc7a3b081d3e97a4c84356',1,'view.Welcome.load()']]]
];
