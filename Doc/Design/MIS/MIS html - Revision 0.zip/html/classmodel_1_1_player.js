var classmodel_1_1_player =
[
    [ "Player", "classmodel_1_1_player.html#a6922d8b0b084510c84540a3497504ed3", null ],
    [ "checkLoss", "classmodel_1_1_player.html#a1027595469ab5de940ba2f6cbb29e5ef", null ],
    [ "decrementLife", "classmodel_1_1_player.html#a5551dad23bcab60638b37c8f54dd6796", null ],
    [ "getScore", "classmodel_1_1_player.html#a9e027a7ee08d451cde3e6743e2ef1d6d", null ],
    [ "LIFE", "classmodel_1_1_player.html#a59153913ee338710aa1a33b68e5d0dbd", null ],
    [ "NOLIFE", "classmodel_1_1_player.html#ad422bd3896f6c86c74fe49be0cae6759", null ],
    [ "score", "classmodel_1_1_player.html#ad6d852aea99befddd30bb094222123d2", null ]
];