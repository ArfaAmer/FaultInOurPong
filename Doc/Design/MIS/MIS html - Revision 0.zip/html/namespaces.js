var namespaces =
[
    [ "model", "namespacemodel.html", null ],
    [ "startGame", "namespacestart_game.html", null ],
    [ "view", "namespaceview.html", null ]
];