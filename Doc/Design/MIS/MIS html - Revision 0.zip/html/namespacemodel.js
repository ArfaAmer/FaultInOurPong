var namespacemodel =
[
    [ "Ball", "classmodel_1_1_ball.html", "classmodel_1_1_ball" ],
    [ "GameModel", "classmodel_1_1_game_model.html", "classmodel_1_1_game_model" ],
    [ "Paddle", "classmodel_1_1_paddle.html", "classmodel_1_1_paddle" ],
    [ "Player", "classmodel_1_1_player.html", "classmodel_1_1_player" ]
];