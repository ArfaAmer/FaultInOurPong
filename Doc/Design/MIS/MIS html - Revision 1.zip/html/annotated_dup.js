var annotated_dup =
[
    [ "model", "namespacemodel.html", "namespacemodel" ],
    [ "startGame", "namespacestart_game.html", "namespacestart_game" ],
    [ "view", "namespaceview.html", "namespaceview" ]
];