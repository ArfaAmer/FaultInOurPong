var classmodel_1_1_player_test =
[
    [ "setUp", "classmodel_1_1_player_test.html#aa538b9f9a18f9610fb2a59c885e7dd22", null ],
    [ "tearDown", "classmodel_1_1_player_test.html#a4ee688549fa5b888772992bd4a1195c2", null ],
    [ "testCheckLoss", "classmodel_1_1_player_test.html#a12200ccc0a720c69c56ad02ebe072e4d", null ],
    [ "testDecrementLife", "classmodel_1_1_player_test.html#a59b6ec1aa25b29d3d6acc5931852f5b2", null ],
    [ "testResetScore", "classmodel_1_1_player_test.html#a6e1c560081d31f373919b80a3c03fce1", null ],
    [ "testSetScore", "classmodel_1_1_player_test.html#a9733b1de2e3ca1ce5155d9b1bffd5091", null ]
];