var classmodel_1_1_high_score =
[
    [ "HighScore", "classmodel_1_1_high_score.html#a406d9d02076784243ea99eec9a6d3e2a", null ],
    [ "returnLowest", "classmodel_1_1_high_score.html#a79ea8cff0a7f98a8bfc3bf4d2d7f7095", null ]
];