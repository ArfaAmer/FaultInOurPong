var searchData=
[
  ['resume',['resume',['../classstart_game_1_1_game_controller.html#ac9d9ab5f3250992c17d93614754dc0d4',1,'startGame.GameController.resume()'],['../classview_1_1_game_view.html#a51484e496307a01d4f261b3ab8517171',1,'view.GameView.resume()']]]
];
