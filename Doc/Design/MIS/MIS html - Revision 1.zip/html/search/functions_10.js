var searchData=
[
  ['welcome',['Welcome',['../classview_1_1_welcome.html#ac0d0158b691ccb4dbca2c78145e4a522',1,'view::Welcome']]],
  ['writeto',['writeTo',['../classview_1_1_high_score.html#a9af7c2f40f565d5953bab616caba2cba',1,'view::HighScore']]]
];
