var searchData=
[
  ['highscore',['HighScore',['../classview_1_1_high_score.html#a8615eb74f2bec128dd66e6b913840471',1,'view::HighScore']]],
  ['highscorepage',['highScorePage',['../classview_1_1_high_score.html#ab59f17eedb6b8656d62e27529e590d1e',1,'view::HighScore']]],
  ['highscores',['highScores',['../classview_1_1_welcome.html#a5d23e93f1a81a2520d5635ed7d8d5920',1,'view::Welcome']]]
];
