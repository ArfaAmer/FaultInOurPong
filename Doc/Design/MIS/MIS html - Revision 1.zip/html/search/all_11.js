var searchData=
[
  ['v',['v',['../classstart_game_1_1_game_controller.html#a86e3c6ba6e8d0ecb0946da48fa55e7ee',1,'startGame::GameController']]],
  ['velx',['velX',['../classstart_game_1_1_game_controller.html#a9de0dcbec624980f8b3808daa96ef457',1,'startGame::GameController']]],
  ['view',['view',['../namespaceview.html',1,'']]]
];
