var searchData=
[
  ['ishigh',['isHigh',['../classview_1_1_high_score.html#a5632c4ab61dd38cf45411469b618fb4e',1,'view::HighScore']]]
];
