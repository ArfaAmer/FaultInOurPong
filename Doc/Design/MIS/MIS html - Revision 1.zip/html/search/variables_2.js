var searchData=
[
  ['displayscore',['displayScore',['../classstart_game_1_1_game_controller.html#a645a34e4b5c875e7fe0dcedc18e8df8a',1,'startGame::GameController']]]
];
