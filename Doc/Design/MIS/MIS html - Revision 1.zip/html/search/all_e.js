var searchData=
[
  ['readfrom',['readFrom',['../classview_1_1_high_score.html#a20136420ca6a7d277df6e1606a68b91d',1,'view::HighScore']]],
  ['resetgame',['resetGame',['../classstart_game_1_1_game_controller.html#a2248f03e8a73083a57b10d4faec5797c',1,'startGame::GameController']]],
  ['resetscore',['resetScore',['../classmodel_1_1_player.html#a1ce780b4bc3a1564934975b18e68df8c',1,'model::Player']]],
  ['resume',['resume',['../classstart_game_1_1_game_controller.html#ac9d9ab5f3250992c17d93614754dc0d4',1,'startGame.GameController.resume()'],['../classview_1_1_game_view.html#a51484e496307a01d4f261b3ab8517171',1,'view.GameView.resume()']]]
];
