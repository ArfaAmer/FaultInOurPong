var searchData=
[
  ['mode',['Mode',['../classview_1_1_mode.html',1,'view']]]
];
