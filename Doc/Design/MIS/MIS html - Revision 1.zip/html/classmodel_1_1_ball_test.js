var classmodel_1_1_ball_test =
[
    [ "setUp", "classmodel_1_1_ball_test.html#a3ae23d6c8b820451fdca9e5a15e76235", null ],
    [ "tearDown", "classmodel_1_1_ball_test.html#a1f02e0db7e2267f15219f247ff198938", null ],
    [ "testGetSize", "classmodel_1_1_ball_test.html#a99d83690977c130f59287816de9790a4", null ],
    [ "testSetPositionX", "classmodel_1_1_ball_test.html#a21ddaa66f3a6786012f5c12f1ae95a93", null ],
    [ "testSetPositionY", "classmodel_1_1_ball_test.html#a1fdcdd0016d745477aadfb2c692c89fe", null ]
];