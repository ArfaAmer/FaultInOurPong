var hierarchy =
[
    [ "model.Ball", "classmodel_1_1_ball.html", null ],
    [ "startGame.GameController", "classstart_game_1_1_game_controller.html", null ],
    [ "model.GameModel", "classmodel_1_1_game_model.html", null ],
    [ "view.GameView", "classview_1_1_game_view.html", null ],
    [ "view.HighScore", "classview_1_1_high_score.html", null ],
    [ "model.Paddle", "classmodel_1_1_paddle.html", null ],
    [ "model.Player", "classmodel_1_1_player.html", null ],
    [ "startGame.PongGame", "classstart_game_1_1_pong_game.html", null ],
    [ "JFrame", null, [
      [ "view.Mode", "classview_1_1_mode.html", null ],
      [ "view.Tutorial", "classview_1_1_tutorial.html", null ],
      [ "view.Welcome", "classview_1_1_welcome.html", null ]
    ] ],
    [ "JPanel", null, [
      [ "view.PongGameDisplay", "classview_1_1_pong_game_display.html", null ]
    ] ]
];